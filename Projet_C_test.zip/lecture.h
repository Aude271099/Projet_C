#include "define.h"


absorp lecture(FILE* file_pf, int* file_state);

absorp init_myabsorp(int a,int b,int c,int d, int centre);